package com.example.model

import androidx.annotation.StringRes
import androidx.compose.ui.graphics.Color
import com.example.R

enum class FaceStyle(
    val id: String,
    @StringRes val titleRes: Int,
    @StringRes val descriptionRes: Int,
    val promptDirective: String
) {
    EFOOTBALL_MODERN(
        id = "efootball_modern",
        titleRes = R.string.style_efootball_title,
        descriptionRes = R.string.style_efootball_desc,
        promptDirective = "modern next-gen eFootball 2024 Unreal Engine 3D player face scan bust render, crisp high-polygon facial geometry, realistic game-engine skin shader with subtle specular highlights, sharp hair strand geometry, athletic neck and jersey collar, dramatic stadium floodlight rim lighting against a clean dark stadium tunnel gradient backdrop"
    ),
    PES_21_CLASSIC(
        id = "pes_21_classic",
        titleRes = R.string.style_pes21_title,
        descriptionRes = R.string.style_pes21_desc,
        promptDirective = "Pro Evolution Soccer 2021 (PES 2021) Fox Engine Edit Mode 3D character face model bust render, authentic 2021 football simulation 3D mesh aesthetic, balanced studio key light and subtle rim light, smooth game-engine skin texture, crisp jawline and cheekbones, clean dark neutral edit-mode studio background"
    ),
    MODEL_TURNAROUND(
        id = "model_turnaround",
        titleRes = R.string.style_turnaround_title,
        descriptionRes = R.string.style_turnaround_desc,
        promptDirective = "3D football game player face sculpt in a dynamic three-quarter (3/4) angle bust pose like eFootball and PES 2021 character edit viewer, showcasing pronounced 3D depth of the nose bridge, brow ridge, cheekbones, and hair volume, wearing a football jersey collar, clean dark studio gradient background with soft cyan and white rim lighting"
    )
}

enum class KitColor(
    val id: String,
    val displayColor: Color,
    val promptColorDescription: String
) {
    EMERALD("emerald", Color(0xFF00C853), "vibrant emerald green and dark navy"),
    ROYAL_BLUE("royal_blue", Color(0xFF2979FF), "royal blue and white"),
    CRIMSON_RED("crimson_red", Color(0xFFE53935), "deep crimson red and white"),
    CLASSIC_WHITE("classic_white", Color(0xFFF1F5F9), "crisp white and gold"),
    OBSIDIAN_BLACK("obsidian_black", Color(0xFF1E293B), "matte black and gold")
}

data class SavedFaceCreation(
    val id: String,
    val createdAtMillis: Long,
    val styleId: String,
    val kitColorId: String,
    val originalPath: String,
    val generatedPath: String
) {
    val style: FaceStyle
        get() = FaceStyle.entries.firstOrNull { it.id == styleId } ?: FaceStyle.EFOOTBALL_MODERN

    val kitColor: KitColor
        get() = KitColor.entries.firstOrNull { it.id == kitColorId } ?: KitColor.EMERALD
}
