package com.example.viewmodel

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.ai.Face3DRepository
import com.example.data.CreationStorageRepository
import com.example.data.GalleryExportResult
import com.example.model.FaceStyle
import com.example.model.KitColor
import com.example.model.SavedFaceCreation
import com.google.firebase.ai.type.QuotaExceededException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.io.File

private const val TAG = "FaceStudioViewModel"
private const val GENERATION_TIMEOUT_MS = 60_000L

sealed interface ConversionUiState {
    data object Idle : ConversionUiState
    data object Loading : ConversionUiState
    data class Success(
        val creation: SavedFaceCreation,
        val generatedBitmap: Bitmap,
        val originalBitmap: Bitmap
    ) : ConversionUiState

    data class Error(val message: String) : ConversionUiState
}

enum class AppTab {
    STUDIO,
    GALLERY
}

class FaceStudioViewModel(application: Application) : AndroidViewModel(application) {

    private val face3DRepository = Face3DRepository()
    private val storageRepository = CreationStorageRepository(application.applicationContext)

    private val _selectedTab = MutableStateFlow(AppTab.STUDIO)
    val selectedTab: StateFlow<AppTab> = _selectedTab.asStateFlow()

    private val _selectedSourceUri = MutableStateFlow<Uri?>(null)
    val selectedSourceUri: StateFlow<Uri?> = _selectedSourceUri.asStateFlow()

    private val _selectedSourceBitmap = MutableStateFlow<Bitmap?>(null)
    val selectedSourceBitmap: StateFlow<Bitmap?> = _selectedSourceBitmap.asStateFlow()

    private val _selectedStyle = MutableStateFlow(FaceStyle.EFOOTBALL_MODERN)
    val selectedStyle: StateFlow<FaceStyle> = _selectedStyle.asStateFlow()

    private val _selectedKitColor = MutableStateFlow(KitColor.EMERALD)
    val selectedKitColor: StateFlow<KitColor> = _selectedKitColor.asStateFlow()

    private val _conversionState = MutableStateFlow<ConversionUiState>(ConversionUiState.Idle)
    val conversionState: StateFlow<ConversionUiState> = _conversionState.asStateFlow()

    private val _savedCreations = MutableStateFlow<List<SavedFaceCreation>>(emptyList())
    val savedCreations: StateFlow<List<SavedFaceCreation>> = _savedCreations.asStateFlow()

    private val _snackbarMessages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val snackbarMessages: SharedFlow<String> = _snackbarMessages.asSharedFlow()

    private val _pendingSafExport = MutableSharedFlow<GalleryExportResult.NeedsSafDocument>(extraBufferCapacity = 1)
    val pendingSafExport: SharedFlow<GalleryExportResult.NeedsSafDocument> = _pendingSafExport.asSharedFlow()

    private val _shareIntents = MutableSharedFlow<Intent>(extraBufferCapacity = 1)
    val shareIntents: SharedFlow<Intent> = _shareIntents.asSharedFlow()

    init {
        viewModelScope.launch {
            _savedCreations.value = storageRepository.loadCreations()
        }
    }

    fun selectTab(tab: AppTab) {
        _selectedTab.value = tab
    }

    fun selectStyle(style: FaceStyle) {
        _selectedStyle.value = style
    }

    fun selectKitColor(color: KitColor) {
        _selectedKitColor.value = color
    }

    fun onPhotoPicked(uri: Uri) {
        val context = getApplication<Application>()
        viewModelScope.launch {
            val decoded = face3DRepository.decodePortraitBitmap(context, uri)
            if (decoded != null) {
                _selectedSourceUri.value = uri
                _selectedSourceBitmap.value = decoded
                if (_conversionState.value !is ConversionUiState.Loading) {
                    _conversionState.value = ConversionUiState.Idle
                }
            } else {
                _snackbarMessages.tryEmit(context.getString(R.string.msg_photo_load_error))
            }
        }
    }

    fun createCameraCaptureUri(): Uri = storageRepository.createCameraOutputUri()

    fun convertSelectedFace() {
        val sourceBitmap = _selectedSourceBitmap.value ?: return
        val style = _selectedStyle.value
        val kitColor = _selectedKitColor.value
        val context = getApplication<Application>()

        viewModelScope.launch {
            _conversionState.value = ConversionUiState.Loading
            try {
                val generatedBitmap = withTimeout(GENERATION_TIMEOUT_MS) {
                    face3DRepository.generate3DFace(
                        inputBitmap = sourceBitmap,
                        style = style,
                        kitColor = kitColor
                    )
                }

                if (generatedBitmap != null) {
                    val savedItem = storageRepository.saveCreation(
                        originalBitmap = sourceBitmap,
                        generatedBitmap = generatedBitmap,
                        style = style,
                        kitColor = kitColor
                    )
                    _savedCreations.value = storageRepository.loadCreations()
                    _conversionState.value = ConversionUiState.Success(
                        creation = savedItem,
                        generatedBitmap = generatedBitmap,
                        originalBitmap = sourceBitmap
                    )
                } else {
                    _conversionState.value = ConversionUiState.Error(
                        context.getString(R.string.msg_error_empty)
                    )
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "3D face conversion timed out", e)
                _conversionState.value = ConversionUiState.Error(
                    context.getString(R.string.msg_error_timeout)
                )
            } catch (e: QuotaExceededException) {
                Log.e(TAG, "Quota exceeded during 3D face conversion", e)
                _conversionState.value = ConversionUiState.Error(
                    context.getString(R.string.msg_error_quota)
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "3D face conversion failed", e)
                _conversionState.value = ConversionUiState.Error(
                    e.localizedMessage ?: "حدث خطأ غير متوقع أثناء التحويل."
                )
            }
        }
    }

    fun resetStudio() {
        _selectedSourceUri.value = null
        _selectedSourceBitmap.value = null
        _conversionState.value = ConversionUiState.Idle
    }

    fun saveToDeviceGallery(generatedFilePath: String) {
        val context = getApplication<Application>()
        viewModelScope.launch {
            when (val result = storageRepository.exportToDeviceGallery(File(generatedFilePath))) {
                is GalleryExportResult.SavedDirectly -> {
                    _snackbarMessages.tryEmit(context.getString(R.string.msg_saved_gallery))
                }
                is GalleryExportResult.NeedsSafDocument -> {
                    _pendingSafExport.tryEmit(result)
                }
                is GalleryExportResult.Failed -> {
                    _snackbarMessages.tryEmit(
                        "${context.getString(R.string.msg_save_error)} (${result.reason})"
                    )
                }
            }
        }
    }

    fun completeSafExport(sourceFile: File, targetUri: Uri) {
        val context = getApplication<Application>()
        viewModelScope.launch {
            val ok = storageRepository.writeToDocumentUri(sourceFile, targetUri)
            _snackbarMessages.tryEmit(
                if (ok) context.getString(R.string.msg_saved_gallery)
                else context.getString(R.string.msg_save_error)
            )
        }
    }

    fun shareCreation(generatedFilePath: String) {
        val intent = storageRepository.createShareIntent(File(generatedFilePath))
        if (intent != null) {
            _shareIntents.tryEmit(intent)
        }
    }

    fun deleteCreation(id: String) {
        viewModelScope.launch {
            _savedCreations.value = storageRepository.deleteCreation(id)
        }
    }
}
