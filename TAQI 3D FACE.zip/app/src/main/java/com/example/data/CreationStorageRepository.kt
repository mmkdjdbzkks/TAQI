package com.example.data

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import com.example.model.FaceStyle
import com.example.model.KitColor
import com.example.model.SavedFaceCreation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

private const val TAG = "CreationStorage"
private const val CREATIONS_DIR = "face_creations"
private const val INDEX_FILE = "creations_index.json"

sealed interface GalleryExportResult {
    data object SavedDirectly : GalleryExportResult
    data class NeedsSafDocument(val suggestedFileName: String, val sourceFile: File) : GalleryExportResult
    data class Failed(val reason: String) : GalleryExportResult
}

class CreationStorageRepository(private val context: Context) {

    private val creationsDir: File
        get() = File(context.filesDir, CREATIONS_DIR).apply {
            if (!exists()) mkdirs()
        }

    private val indexFile: File
        get() = File(creationsDir, INDEX_FILE)

    suspend fun loadCreations(): List<SavedFaceCreation> = withContext(Dispatchers.IO) {
        if (!indexFile.exists()) return@withContext emptyList()
        try {
            val raw = indexFile.readText()
            if (raw.isBlank()) return@withContext emptyList()
            val array = JSONArray(raw)
            val result = mutableListOf<SavedFaceCreation>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val generatedPath = obj.getString("generatedPath")
                val originalPath = obj.getString("originalPath")
                if (File(generatedPath).exists()) {
                    result.add(
                        SavedFaceCreation(
                            id = obj.getString("id"),
                            createdAtMillis = obj.getLong("createdAtMillis"),
                            styleId = obj.getString("styleId"),
                            kitColorId = obj.getString("kitColorId"),
                            originalPath = originalPath,
                            generatedPath = generatedPath
                        )
                    )
                }
            }
            result.sortedByDescending { it.createdAtMillis }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load saved creations", e)
            emptyList()
        }
    }

    suspend fun saveCreation(
        originalBitmap: Bitmap,
        generatedBitmap: Bitmap,
        style: FaceStyle,
        kitColor: KitColor
    ): SavedFaceCreation = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val origFile = File(creationsDir, "${id}_orig.jpg")
        val genFile = File(creationsDir, "${id}_3d.png")

        FileOutputStream(origFile).use { out ->
            originalBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        FileOutputStream(genFile).use { out ->
            generatedBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }

        val item = SavedFaceCreation(
            id = id,
            createdAtMillis = now,
            styleId = style.id,
            kitColorId = kitColor.id,
            originalPath = origFile.absolutePath,
            generatedPath = genFile.absolutePath
        )

        val current = loadCreations().toMutableList()
        current.add(0, item)
        writeIndex(current)
        item
    }

    suspend fun deleteCreation(id: String): List<SavedFaceCreation> = withContext(Dispatchers.IO) {
        val current = loadCreations().toMutableList()
        val target = current.firstOrNull { it.id == id }
        if (target != null) {
            runCatching { File(target.originalPath).delete() }
            runCatching { File(target.generatedPath).delete() }
            current.removeAll { it.id == id }
            writeIndex(current)
        }
        current
    }

    suspend fun exportToDeviceGallery(sourceFile: File): GalleryExportResult =
        withContext(Dispatchers.IO) {
            if (!sourceFile.exists()) {
                return@withContext GalleryExportResult.Failed("Source image missing.")
            }
            val fileName = "Face3D_${System.currentTimeMillis()}.png"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(
                            MediaStore.Images.Media.RELATIVE_PATH,
                            "${Environment.DIRECTORY_PICTURES}/Face3D"
                        )
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        ?: return@withContext GalleryExportResult.Failed("MediaStore insert returned null.")

                    resolver.openOutputStream(uri)?.use { out ->
                        sourceFile.inputStream().use { input -> input.copyTo(out) }
                    }
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    GalleryExportResult.SavedDirectly
                } catch (e: Exception) {
                    Log.e(TAG, "MediaStore gallery export failed", e)
                    GalleryExportResult.Failed(e.localizedMessage ?: "Export error")
                }
            } else {
                // Android 9 (API 28) and lower: zero-permission Storage Access Framework prompt
                GalleryExportResult.NeedsSafDocument(fileName, sourceFile)
            }
        }

    suspend fun writeToDocumentUri(sourceFile: File, targetUri: Uri): Boolean =
        withContext(Dispatchers.IO) {
            try {
                context.contentResolver.openOutputStream(targetUri)?.use { out ->
                    sourceFile.inputStream().use { input -> input.copyTo(out) }
                }
                true
            } catch (e: Exception) {
                Log.e(TAG, "Failed writing SAF document", e)
                false
            }
        }

    fun createCameraOutputUri(): Uri {
        val cameraDir = File(context.cacheDir, "camera").apply {
            if (!exists()) mkdirs()
        }
        val photoFile = File(cameraDir, "capture_${System.currentTimeMillis()}.jpg")
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            photoFile
        )
    }

    fun createShareIntent(imageFile: File): Intent? {
        if (!imageFile.exists()) return null
        val shareDir = File(context.cacheDir, "shared").apply {
            if (!exists()) mkdirs()
        }
        val shareFile = File(shareDir, "face3d_share.png")
        imageFile.copyTo(shareFile, overwrite = true)

        val contentUri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            shareFile
        )
        return Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, contentUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun writeIndex(items: List<SavedFaceCreation>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("createdAtMillis", item.createdAtMillis)
                    put("styleId", item.styleId)
                    put("kitColorId", item.kitColorId)
                    put("originalPath", item.originalPath)
                    put("generatedPath", item.generatedPath)
                }
            )
        }
        indexFile.writeText(array.toString())
    }
}
