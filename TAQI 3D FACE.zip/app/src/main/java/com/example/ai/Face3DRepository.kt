package com.example.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.util.Log
import com.example.model.FaceStyle
import com.example.model.KitColor
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.ImagePart
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import kotlin.math.max

private const val TAG = "Face3DRepository"
private const val MAX_INPUT_DIMENSION = 1024

class Face3DRepository {

    private val imageModel: GenerativeModel by lazy {
        val config = generationConfig {
            responseModalities = listOf(ResponseModality.IMAGE)
        }
        Firebase.ai.generativeModel(
            modelName = "gemini-nano-banana-2.1",
            generationConfig = config
        )
    }

    suspend fun generate3DFace(
        inputBitmap: Bitmap,
        style: FaceStyle,
        kitColor: KitColor
    ): Bitmap? = withContext(Dispatchers.IO) {
        val scaledInput = scaleBitmapIfNeeded(inputBitmap, MAX_INPUT_DIMENSION)
        val prompt = buildConversionPrompt(style, kitColor)
        Log.d(TAG, "Starting 3D face conversion with style=${style.id}, kit=${kitColor.id}")

        val response = imageModel.generateContent(
            content {
                image(scaledInput)
                text(prompt)
            }
        )

        val imagePart = response.candidates.firstOrNull()
            ?.content?.parts?.filterIsInstance<ImagePart>()
            ?.firstOrNull()

        imagePart?.image
    }

    suspend fun decodePortraitBitmap(context: Context, uri: Uri): Bitmap? =
        withContext(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                        decoder.isMutableRequired = false
                        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        val width = info.size.width
                        val height = info.size.height
                        val largest = max(width, height)
                        if (largest > MAX_INPUT_DIMENSION) {
                            val ratio = MAX_INPUT_DIMENSION.toFloat() / largest.toFloat()
                            decoder.setTargetSize(
                                (width * ratio).toInt().coerceAtLeast(1),
                                (height * ratio).toInt().coerceAtLeast(1)
                            )
                        }
                    }
                } else {
                    decodeLegacyBitmap(context, uri)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to decode image from URI: $uri", e)
                null
            }
        }

    private fun decodeLegacyBitmap(context: Context, uri: Uri): Bitmap? {
        val boundsOptions = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, boundsOptions)
        }
        var sampleSize = 1
        val largest = max(boundsOptions.outWidth, boundsOptions.outHeight)
        while (largest / sampleSize > MAX_INPUT_DIMENSION * 2) {
            sampleSize *= 2
        }
        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val rawBitmap = context.contentResolver.openInputStream(uri)?.use { stream: InputStream ->
            BitmapFactory.decodeStream(stream, null, decodeOptions)
        } ?: return null

        return scaleBitmapIfNeeded(rawBitmap, MAX_INPUT_DIMENSION)
    }

    private fun scaleBitmapIfNeeded(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val largest = max(width, height)
        if (largest <= maxDimension) return bitmap

        val scale = maxDimension.toFloat() / largest.toFloat()
        val matrix = Matrix().apply { postScale(scale, scale) }
        return Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true)
    }

    private fun buildConversionPrompt(style: FaceStyle, kitColor: KitColor): String {
        return """
            Transform the person in the input photo into a ${style.promptDirective}.
            Strict requirements:
            - Preserve the exact facial identity, bone structure, eye shape, eyebrows, nose, lips, skin tone, facial hair, and hairstyle of the person in the photo.
            - Render as a clean 3D football video game character head-and-shoulders portrait bust (centered, chest-up framing) suitable for a player profile in eFootball or PES 2021.
            - Dress the player's shoulders and collar in a sleek ${kitColor.promptColorDescription} football jersey kit.
            - No text, no watermarks, no UI overlays, no logos, and no borders.
        """.trimIndent()
    }
}
