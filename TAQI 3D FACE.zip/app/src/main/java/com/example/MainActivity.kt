package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.FaceRetouchingNatural
import androidx.compose.material.icons.outlined.Collections
import androidx.compose.material.icons.outlined.FaceRetouchingNatural
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ai.configureAppCheck
import com.example.data.GalleryExportResult
import com.example.ui.screens.GalleryScreen
import com.example.ui.screens.StudioScreen
import com.example.ui.theme.Face3DTheme
import com.example.ui.theme.PitchEmerald
import com.example.ui.theme.PitchVoid
import com.example.ui.theme.TunnelSlate
import com.example.viewmodel.AppTab
import com.example.viewmodel.FaceStudioViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure Firebase App Check with launch intent before UI or ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(PitchVoid.toArgb()),
            navigationBarStyle = SystemBarStyle.dark(TunnelSlate.toArgb())
        )

        setContent {
            Face3DTheme {
                Face3DApp()
            }
        }
    }
}

@Composable
fun Face3DApp(
    viewModel: FaceStudioViewModel = viewModel()
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val sourceBitmap by viewModel.selectedSourceBitmap.collectAsStateWithLifecycle()
    val selectedStyle by viewModel.selectedStyle.collectAsStateWithLifecycle()
    val selectedKitColor by viewModel.selectedKitColor.collectAsStateWithLifecycle()
    val conversionState by viewModel.conversionState.collectAsStateWithLifecycle()
    val savedCreations by viewModel.savedCreations.collectAsStateWithLifecycle()

    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var pendingSafSource by remember { mutableStateOf<GalleryExportResult.NeedsSafDocument?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.onPhotoPicked(uri)
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) {
            viewModel.onPhotoPicked(uri)
        }
    }

    val safDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("image/png")
    ) { targetUri ->
        val pending = pendingSafSource
        if (targetUri != null && pending != null) {
            viewModel.completeSafExport(pending.sourceFile, targetUri)
        }
        pendingSafSource = null
    }

    LaunchedEffect(Unit) {
        viewModel.snackbarMessages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.pendingSafExport.collect { safRequest ->
            pendingSafSource = safRequest
            safDocumentLauncher.launch(safRequest.suggestedFileName)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.shareIntents.collect { shareIntent ->
            val chooser = Intent.createChooser(
                shareIntent,
                context.getString(R.string.btn_share)
            )
            context.startActivity(chooser)
        }
    }

    if (selectedTab == AppTab.GALLERY) {
        BackHandler {
            viewModel.selectTab(AppTab.STUDIO)
        }
    }

    val launchGalleryPicker = {
        photoPickerLauncher.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
        )
    }

    val scope = rememberCoroutineScope()

    val launchCameraCapture: () -> Unit = {
        try {
            val outputUri = viewModel.createCameraCaptureUri()
            pendingCameraUri = outputUri
            cameraLauncher.launch(outputUri)
        } catch (_: Exception) {
            scope.launch {
                snackbarHostState.showSnackbar(context.getString(R.string.msg_camera_error))
            }
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = PitchVoid,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar(
                        containerColor = TunnelSlate
                    ) {
                        NavigationBarItem(
                            selected = selectedTab == AppTab.STUDIO,
                            onClick = { viewModel.selectTab(AppTab.STUDIO) },
                            icon = {
                                Icon(
                                    imageVector = if (selectedTab == AppTab.STUDIO) {
                                        Icons.Filled.FaceRetouchingNatural
                                    } else {
                                        Icons.Outlined.FaceRetouchingNatural
                                    },
                                    contentDescription = stringResource(R.string.nav_studio)
                                )
                            },
                            label = { Text(stringResource(R.string.nav_studio)) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PitchEmerald,
                                selectedTextColor = PitchEmerald,
                                indicatorColor = PitchEmerald.copy(alpha = 0.16f)
                            ),
                            modifier = Modifier.testTag("nav_studio_tab")
                        )
                        NavigationBarItem(
                            selected = selectedTab == AppTab.GALLERY,
                            onClick = { viewModel.selectTab(AppTab.GALLERY) },
                            icon = {
                                Icon(
                                    imageVector = if (selectedTab == AppTab.GALLERY) {
                                        Icons.Filled.Collections
                                    } else {
                                        Icons.Outlined.Collections
                                    },
                                    contentDescription = stringResource(R.string.nav_gallery)
                                )
                            },
                            label = { Text(stringResource(R.string.nav_gallery)) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PitchEmerald,
                                selectedTextColor = PitchEmerald,
                                indicatorColor = PitchEmerald.copy(alpha = 0.16f)
                            ),
                            modifier = Modifier.testTag("nav_gallery_tab")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail(
                        containerColor = TunnelSlate
                    ) {
                        NavigationRailItem(
                            selected = selectedTab == AppTab.STUDIO,
                            onClick = { viewModel.selectTab(AppTab.STUDIO) },
                            icon = {
                                Icon(
                                    imageVector = if (selectedTab == AppTab.STUDIO) {
                                        Icons.Filled.FaceRetouchingNatural
                                    } else {
                                        Icons.Outlined.FaceRetouchingNatural
                                    },
                                    contentDescription = stringResource(R.string.nav_studio)
                                )
                            },
                            label = { Text(stringResource(R.string.nav_studio)) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = PitchEmerald,
                                selectedTextColor = PitchEmerald,
                                indicatorColor = PitchEmerald.copy(alpha = 0.16f)
                            )
                        )
                        NavigationRailItem(
                            selected = selectedTab == AppTab.GALLERY,
                            onClick = { viewModel.selectTab(AppTab.GALLERY) },
                            icon = {
                                Icon(
                                    imageVector = if (selectedTab == AppTab.GALLERY) {
                                        Icons.Filled.Collections
                                    } else {
                                        Icons.Outlined.Collections
                                    },
                                    contentDescription = stringResource(R.string.nav_gallery)
                                )
                            },
                            label = { Text(stringResource(R.string.nav_gallery)) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = PitchEmerald,
                                selectedTextColor = PitchEmerald,
                                indicatorColor = PitchEmerald.copy(alpha = 0.16f)
                            )
                        )
                    }
                }

                when (selectedTab) {
                    AppTab.STUDIO -> StudioScreen(
                        sourceBitmap = sourceBitmap,
                        selectedStyle = selectedStyle,
                        selectedKitColor = selectedKitColor,
                        conversionState = conversionState,
                        onPickFromGallery = launchGalleryPicker,
                        onCapturePhoto = launchCameraCapture,
                        onSelectStyle = viewModel::selectStyle,
                        onSelectKitColor = viewModel::selectKitColor,
                        onConvertClick = viewModel::convertSelectedFace,
                        onSaveToGallery = viewModel::saveToDeviceGallery,
                        onShare = viewModel::shareCreation,
                        onReset = viewModel::resetStudio,
                        modifier = Modifier.weight(1f)
                    )

                    AppTab.GALLERY -> GalleryScreen(
                        creations = savedCreations,
                        onGoToStudio = { viewModel.selectTab(AppTab.STUDIO) },
                        onSaveToGallery = viewModel::saveToDeviceGallery,
                        onShare = viewModel::shareCreation,
                        onDelete = viewModel::deleteCreation,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
