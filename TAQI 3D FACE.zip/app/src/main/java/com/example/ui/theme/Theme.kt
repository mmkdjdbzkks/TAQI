package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val StadiumDarkColorScheme = darkColorScheme(
    primary = PitchEmerald,
    onPrimary = OnPitchEmerald,
    primaryContainer = TacticalCardElevated,
    onPrimaryContainer = PitchEmerald,
    secondary = StadiumGold,
    onSecondary = OnStadiumGold,
    secondaryContainer = ColorTokens.GoldTint,
    onSecondaryContainer = StadiumGold,
    tertiary = ScanCyan,
    onTertiary = OnScanCyan,
    background = PitchVoid,
    onBackground = TextPrimary,
    surface = TunnelSlate,
    onSurface = TextPrimary,
    surfaceVariant = TacticalCard,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLow = TunnelSlate,
    surfaceContainer = TacticalCard,
    surfaceContainerHigh = TacticalCardElevated,
    outline = TacticalBorder,
    outlineVariant = TacticalBorder.copy(alpha = 0.55f),
    error = ErrorCrimson,
    onError = TextPrimary,
    errorContainer = ErrorContainerDark,
    onErrorContainer = TextPrimary
)

private object ColorTokens {
    val GoldTint = androidx.compose.ui.graphics.Color(0xFF2B210B)
}

private val StadiumShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun Face3DTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StadiumDarkColorScheme,
        typography = AppTypography,
        shapes = StadiumShapes,
        content = content
    )
}
