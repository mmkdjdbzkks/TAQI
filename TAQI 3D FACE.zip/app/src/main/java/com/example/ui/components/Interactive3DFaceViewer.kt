package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ViewInAr
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.PitchEmerald
import com.example.ui.theme.ScanCyan
import com.example.ui.theme.StadiumGold
import com.example.ui.theme.TacticalBorder
import com.example.ui.theme.TacticalCard
import java.io.File

@Composable
fun Interactive3DFaceViewer(
    generatedBitmap: Bitmap? = null,
    originalBitmap: Bitmap? = null,
    generatedFilePath: String? = null,
    originalFilePath: String? = null,
    styleLabel: String,
    modifier: Modifier = Modifier
) {
    var showOriginal by remember { mutableStateOf(false) }
    var targetRotationX by remember { mutableFloatStateOf(0f) }
    var targetRotationY by remember { mutableFloatStateOf(0f) }

    val animatedRotationX by animateFloatAsState(
        targetValue = targetRotationX,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "rotationX"
    )
    val animatedRotationY by animateFloatAsState(
        targetValue = targetRotationY,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "rotationY"
    )

    val density = LocalDensity.current.density

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .graphicsLayer {
                    rotationX = animatedRotationX
                    rotationY = animatedRotationY
                    cameraDistance = 12f * density
                }
                .clip(RoundedCornerShape(24.dp))
                .background(TacticalCard)
                .border(
                    width = 1.5.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            PitchEmerald.copy(alpha = 0.7f),
                            ScanCyan.copy(alpha = 0.4f),
                            StadiumGold.copy(alpha = 0.6f)
                        )
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragEnd = {
                            targetRotationX = 0f
                            targetRotationY = 0f
                        },
                        onDragCancel = {
                            targetRotationX = 0f
                            targetRotationY = 0f
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            targetRotationY = (targetRotationY + dragAmount.x * 0.14f)
                                .coerceIn(-20f, 20f)
                            targetRotationX = (targetRotationX - dragAmount.y * 0.14f)
                                .coerceIn(-14f, 14f)
                        }
                    )
                }
                .testTag("interactive_3d_viewer")
        ) {
            AnimatedContent(
                targetState = showOriginal,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "compare_toggle"
            ) { displayOriginal ->
                if (displayOriginal) {
                    when {
                        originalBitmap != null -> Image(
                            bitmap = originalBitmap.asImageBitmap(),
                            contentDescription = stringResource(R.string.btn_compare_original),
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        !originalFilePath.isNullOrBlank() -> AsyncImage(
                            model = File(originalFilePath),
                            contentDescription = stringResource(R.string.btn_compare_original),
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                } else {
                    when {
                        generatedBitmap != null -> Image(
                            bitmap = generatedBitmap.asImageBitmap(),
                            contentDescription = stringResource(R.string.result_title),
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        !generatedFilePath.isNullOrBlank() -> AsyncImage(
                            model = File(generatedFilePath),
                            contentDescription = stringResource(R.string.result_title),
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }

            // Dynamic stadium light specular sheen reacting to 3D drag tilt
            Canvas(modifier = Modifier.fillMaxSize()) {
                val shiftX = (animatedRotationY / 20f) * size.width * 0.35f
                val shiftY = (-animatedRotationX / 14f) * size.height * 0.35f
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        center = Offset(
                            x = size.width * 0.5f + shiftX,
                            y = size.height * 0.32f + shiftY
                        ),
                        radius = size.minDimension * 0.65f
                    )
                )

                // Subtle Edit Mode HUD corner reticles
                val stroke = 2.5.dp.toPx()
                val arm = 18.dp.toPx()
                val pad = 14.dp.toPx()
                val hudColor = if (showOriginal) StadiumGold else PitchEmerald
                // Top-left
                drawLine(hudColor, Offset(pad, pad), Offset(pad + arm, pad), stroke)
                drawLine(hudColor, Offset(pad, pad), Offset(pad, pad + arm), stroke)
                // Top-right
                drawLine(hudColor, Offset(size.width - pad, pad), Offset(size.width - pad - arm, pad), stroke)
                drawLine(hudColor, Offset(size.width - pad, pad), Offset(size.width - pad, pad + arm), stroke)
                // Bottom-left
                drawLine(hudColor, Offset(pad, size.height - pad), Offset(pad + arm, size.height - pad), stroke)
                drawLine(hudColor, Offset(pad, size.height - pad), Offset(pad, size.height - pad - arm), stroke)
                // Bottom-right
                drawLine(hudColor, Offset(size.width - pad, size.height - pad), Offset(size.width - pad - arm, size.height - pad), stroke)
                drawLine(hudColor, Offset(size.width - pad, size.height - pad), Offset(size.width - pad, size.height - pad - arm), stroke)
            }

            // Top HUD badge
            Surface(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(16.dp),
                shape = RoundedCornerShape(50),
                color = Color.Black.copy(alpha = 0.62f),
                border = androidx.compose.foundation.BorderStroke(1.dp, TacticalBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ViewInAr,
                        contentDescription = null,
                        tint = if (showOriginal) StadiumGold else PitchEmerald,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (showOriginal) stringResource(R.string.btn_compare_original) else styleLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.viewer_hint_drag),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !showOriginal,
                    onClick = { showOriginal = false },
                    label = { Text(stringResource(R.string.btn_compare_3d)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PitchEmerald.copy(alpha = 0.2f),
                        selectedLabelColor = PitchEmerald
                    ),
                    modifier = Modifier.testTag("chip_view_3d")
                )
                FilterChip(
                    selected = showOriginal,
                    onClick = { showOriginal = true },
                    label = { Text(stringResource(R.string.btn_compare_original)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = StadiumGold.copy(alpha = 0.2f),
                        selectedLabelColor = StadiumGold
                    ),
                    modifier = Modifier.testTag("chip_view_original")
                )
            }
        }
    }
}
