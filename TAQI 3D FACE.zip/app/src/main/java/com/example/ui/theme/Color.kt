package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PitchVoid = Color(0xFF0A0F14)
val TunnelSlate = Color(0xFF111924)
val TacticalCard = Color(0xFF16212E)
val TacticalCardElevated = Color(0xFF1D2B3B)
val TacticalBorder = Color(0xFF28394D)

val PitchEmerald = Color(0xFF00E676)
val PitchEmeraldDark = Color(0xFF00B85C)
val OnPitchEmerald = Color(0xFF042112)

val StadiumGold = Color(0xFFF59E0B)
val OnStadiumGold = Color(0xFF261600)

val ScanCyan = Color(0xFF00D4FF)
val OnScanCyan = Color(0xFF001F29)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val ErrorCrimson = Color(0xFFFF5252)
val ErrorContainerDark = Color(0xFF3D1418)
